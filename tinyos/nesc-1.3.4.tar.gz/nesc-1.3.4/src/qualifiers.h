Q(const, 	TYPE_QUAL,	const_qualifier, 	2)
Q(volatile, 	TYPE_QUAL,	volatile_qualifier, 	4)
Q(__restrict,	TYPE_QUAL,	restrict_qualifier,	8)
