/* load libcpp */
#include "system.h"
#include "config.h"
#include "cpplib.h"
#include "line-map.h"
#undef bool
#define TRUE 1
#define FALSE 0
